﻿Module Module1
    'Declaração de Variáveis Públicas
    Public resposta As String 'Reposta MSGB
    Public diretorio As String
    Public db As New ADODB.Connection 'Variável do Banco
    Public rs As New ADODB.Recordset 'Variável das Tabelas 
    Public sql, aux_placa, resp As String 'Query de Leitura e Escrita
    Public cor_selecionada_hex As String = "#FFFFFF" 'Variavel pra conseguir reconhecer a cor no banco
    Public cont As Integer

    Sub Carregar_tipo()
        Try
            ' 1. Preenche as Marcas
            With Form1.cmb_marca.Items
                .Clear() ' Evita duplicar a lista se a função for chamada mais de uma vez
                .Add("Busca por Marca")
                .Add("Chevrolet")
                .Add("Ford")
                .Add("Honda")
                .Add("Toyota")
                .Add("Volkswagen")
                .Add("Fiat")
                .Add("Jeep")
                .Add("BYD")
                .Add("Ferrari")
                .Add("Mercedes")
                .Add("Audi")
            End With
            Form1.cmb_marca.SelectedIndex = 0
            Form1.cmb_marca.DropDownStyle = ComboBoxStyle.DropDownList 'proibe de add outros items

            ' 2. Preenche os Combustíveis
            With Form1.cmb_combustivel.Items
                .Clear()
                .Add("Tipo de Combustível...")
                .Add("Flex")
                .Add("Gasolina")
                .Add("Etanol")
                .Add("Diesel")
                .Add("Elétrico")
                .Add("Híbrido")
            End With
            Form1.cmb_combustivel.SelectedIndex = 0 ' Define "Tipo Combustível..." como padrão
            Form1.cmb_combustivel.DropDownStyle = ComboBoxStyle.DropDownList 'proibe de add outros items

        Catch ex As Exception
            MsgBox("Erro ao Carregar os dados das listas!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub


    Sub Carregar_dados()
        'Carregar Registros do banco no datagridview
        Try
            sql = $"select * from tb_veiculos order by marca asc"
            rs = db.Execute(sql)
            With Form1.dgv_dados
                cont = 0
                .Rows.Clear()

                Do While rs.EOF = False
                    cont = cont + 1
                    .Rows.Add(cont,
                              rs.Fields("placa").Value,
                              rs.Fields("marca").Value,
                              rs.Fields("modelo").Value,
                              rs.Fields("ano").Value,
                              Nothing, 'Cor
                              rs.Fields("combustivel").Value,
                              rs.Fields("km").Value,
                              rs.Fields("venda").Value, ' Pega a venda na coluna VALOR
                              Nothing,
                              Nothing)

                    ' Pinta a célula da COR (Índice 5 da grade)
                    If Not IsDBNull(rs.Fields("cor").Value) Then
                        Dim hexCor As String = rs.Fields("cor").Value.ToString()
                        If Not String.IsNullOrEmpty(hexCor) AndAlso hexCor.StartsWith("#") Then
                            .Rows(cont - 1).Cells(5).Style.BackColor = ColorTranslator.FromHtml(hexCor)
                        End If
                    End If

                    rs.MoveNext()
                Loop
            End With
        Catch ex As Exception
            MsgBox("Erro ao Carregar os dados", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")

        End Try
    End Sub


    Sub Conecta_banco()
        'String de Conexão SQL-SERVER
        Try
            db = CreateObject("ADODB.Connection")
            db.Open("Provider=SQLOLEDB;Data Source=.\SQLEXPRESS;Initial Catalog=cad_veiculos;trusted_connection=yes;")
            MsgBox("Conexão OK", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        Catch ex As Exception
            MsgBox("Erro ao Conectar", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Sub Limpar_cadastro()
        Try
            With Form1
                ' Limpa os campos de texto
                .txt_placa.Clear()
                .txt_marca.Clear()
                .txt_modelo.Clear()
                .txt_ano.Clear()
                .txt_km.Clear()
                .txt_venda.Clear()

                ' Volta os ComboBoxes para a primeira opção ("Selecione...")
                .cmb_marca.SelectedIndex = 0
                .cmb_combustivel.SelectedIndex = 0

                ' Reseta a amostra de cor para a cor padrão (ex: branco ou transparente)
                .pnl_amostra_cor.BackColor = Color.White
                cor_selecionada_hex = "#FFFFFF"

                ' Reseta o caminho da imagem e recarrega a foto padrão de perfil/veículo
                diretorio = ""
                .img_foto.Load(Application.StartupPath & "\fotos\nova_foto.png")

                ' Coloca o cursor de volta no campo de Placa para o próximo cadastro
                .txt_placa.Focus()
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Sub btn_cancelamento()
        Try
            With Form1
                resposta = MsgBox("Você quer cancelar o preenchimento?", vbYesNo + vbQuestion, "ATENÇÃO")

                If resposta = vbYes Then
                    Limpar_cadastro()
                End If
            End With

        Catch ex As Exception

        End Try

    End Sub



End Module
