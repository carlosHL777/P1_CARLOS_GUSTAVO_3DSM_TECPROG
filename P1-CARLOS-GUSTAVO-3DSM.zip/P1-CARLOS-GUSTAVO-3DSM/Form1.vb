﻿'import pra poder ter o placeholder
Imports System.Runtime.InteropServices

Public Class Form1

    ' Importa as rotinas nativas do Windows para mover a janela
    <System.Runtime.InteropServices.DllImport("user32.dll")>
    Private Shared Sub ReleaseCapture()
    End Sub

    <System.Runtime.InteropServices.DllImport("user32.dll")>
    Private Shared Sub SendMessage(hWnd As IntPtr, wMsg As Integer, wParam As Integer, lParam As Integer)
    End Sub

    ' Função DLL específica para o Placeholder
    ' Constante e função para o Placeholder no TextBox
    Private Const EM_SETCUEBANNER As Integer = &H1501

    <DllImport("user32.dll", EntryPoint:="SendMessage", CharSet:=CharSet.Unicode)>
    Private Shared Function SendMessagePlaceholder(ByVal hWnd As IntPtr, ByVal msg As Integer, ByVal wParam As Int32, ByVal lParam As String) As Int32
    End Function



    ' Evento MouseDown do Panel do topo
    Private Sub Panel1_MouseDown(sender As Object, e As MouseEventArgs) Handles Panel1.MouseDown
        If e.Button = MouseButtons.Left Then
            ReleaseCapture()
            SendMessage(Me.Handle, &HA1, 2, 0)
        End If
    End Sub

    'código para salvar foto
    Private Sub Img_foto_Click(sender As Object, e As EventArgs) Handles img_foto.Click
        Try
            With OpenFileDialog1
                .Title = "Selecione uma Foto"
                .InitialDirectory = Application.StartupPath & "\Fotos"
                .ShowDialog()
                diretorio = .FileName
                img_foto.Load(diretorio)
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Conecta_banco()
        Carregar_dados()
        Carregar_tipo()
    End Sub
    Private Sub Form1_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        SendMessagePlaceholder(txt_buscar.Handle, EM_SETCUEBANNER, 1, "Digite Placa ou Modelo...")
    End Sub

    'código para salvar os dados preenchidos
    Private Sub btn_salvar_Click(sender As Object, e As EventArgs) Handles btn_salvar.Click
        Try
            ' 1. Validação simples para evitar campos vazios essenciais
            If String.IsNullOrWhiteSpace(txt_placa.Text) Then
                MsgBox("Por favor, preencha a placa do veículo!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")
                Exit Sub
            End If

            ' 2. Verifica se a placa já está cadastrada no banco
            sql = $"select * from tb_veiculos where placa='{txt_placa.Text}'"
            rs = db.Execute(sql)

            With dgv_dados

                If rs.EOF = True Then
                    'NOVO CADASTRO (INSERT)
                    sql = $"insert into tb_veiculos (placa, marca, modelo, ano, combustivel, cor, km, venda, foto) " &
                      $"values ('{txt_placa.Text.Trim()}', " &
                      $"'{txt_marca.Text.ToUpper}', " &
                      $"'{txt_modelo.Text.ToUpper}', " &
                      $"'{txt_ano.Text}', " &
                      $"'{cmb_combustivel.Text}', " &
                      $"'{cor_selecionada_hex}', " &
                      $"'{txt_km.Text}', " &
                      $"'{txt_venda.Text}', " &
                      $"'{diretorio}')"

                    db.Execute(sql)
                    MsgBox("Veículo gravado com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")

                ElseIf .CurrentRow.Cells(9).Selected = True Then
                    Dim aux_placa As String = .CurrentRow.Cells(1).Value.ToString()

                    sql = $"select * from tb_veiculos where placa='{aux_placa}'"
                    rs = db.Execute(sql)

                    'ATUALIZAÇÃO (UPDATE)
                    sql = $"update tb_veiculos set " &
                          $"marca='{txt_marca.Text}', " &
                          $"modelo='{txt_modelo.Text}', " &
                          $"ano='{txt_ano.Text}', " &
                          $"combustivel='{cmb_combustivel.Text}', " &
                          $"cor='{cor_selecionada_hex}', " &
                          $"km='{txt_km.Text}', " &
                          $"venda='{txt_venda.Text}', " &
                          $"foto='{diretorio}' " &
                          $"where placa='{aux_placa.Trim()}'"

                    db.Execute(sql)
                    MsgBox("Dados atualizados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")

                Else
                    MsgBox("Placa já cadastrada, informe outra por favor.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                End If

            End With

            ' 3. Limpa os campos e atualiza o DataGridView
            Limpar_cadastro()
            Carregar_dados()

        Catch ex As Exception
            MsgBox("Erro ao Gravar os dados do veículo!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Private Sub txt_placa_DoubleClick(sender As Object, e As EventArgs) Handles txt_placa.DoubleClick
        Limpar_cadastro()
    End Sub

    'código para procurar texto
    Private Sub txt_buscar_TextChanged(sender As Object, e As EventArgs) Handles txt_buscar.TextChanged
        Try
            ' Começa a consulta base
            sql = $"select * from tb_veiculos where (placa like '%{txt_buscar.Text}%' or modelo like '%{txt_buscar.Text}%')"

            ' Se uma marca estiver selecionada no ComboBox, adiciona o filtro de marca
            If cmb_marca.SelectedIndex > 0 AndAlso Not String.IsNullOrWhiteSpace(cmb_marca.Text) Then
                sql &= $" and marca='{cmb_marca.Text}'"
            End If

            sql &= " order by marca asc"
            rs = db.Execute(sql)
            With dgv_dados
                cont = 0
                .Rows.Clear()
                Do While rs.EOF = False 'Faça enquanto existir registros
                    cont = cont + 1
                    .Rows.Add(cont,
                                  rs.Fields("placa").Value,
                                  rs.Fields("marca").Value,
                                  rs.Fields("modelo").Value,
                                  rs.Fields("ano").Value,
                                  Nothing, ' Coluna COR
                                  rs.Fields("combustivel").Value,
                                  rs.Fields("km").Value,
                                  rs.Fields("venda").Value,
                                  Nothing, ' Coluna EDITAR
                                  Nothing) ' Coluna EXCLUIR

                    ' Pinta a célula da COR (Índice 5 da grade)
                    If Not IsDBNull(rs.Fields("cor").Value) Then
                        Dim hexCor As String = rs.Fields("cor").Value.ToString()
                        If Not String.IsNullOrEmpty(hexCor) AndAlso hexCor.StartsWith("#") Then
                            .Rows(cont - 1).Cells(5).Style.BackColor = ColorTranslator.FromHtml(hexCor)
                        End If
                    End If

                    rs.MoveNext()
                Loop

            End With
        Catch ex As Exception
            MsgBox("Erro ao Carregar os dados", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    'combobox já filtra sem ter que pesquisar junto
    Private Sub cmb_marca_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_marca.SelectedIndexChanged
        txt_buscar_TextChanged(sender, e)
    End Sub


    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick
        Try
            With dgv_dados
                ' seleciona o editar
                If .CurrentRow.Cells(9).Selected = True Then

                    ' Pega a Placa que está na coluna 1
                    Dim aux_placa As String = .CurrentRow.Cells(1).Value.ToString()

                    sql = $"select * from tb_veiculos where placa='{aux_placa}'"
                    rs = db.Execute(sql)

                    If rs.EOF = False Then
                        ' Preenche os campos da tela usando os nomes das colunas do banco
                        txt_placa.Text = rs.Fields("placa").Value.ToString()
                        txt_marca.Text = rs.Fields("marca").Value.ToString()
                        txt_modelo.Text = rs.Fields("modelo").Value.ToString()
                        txt_ano.Text = rs.Fields("ano").Value.ToString()
                        cmb_combustivel.Text = rs.Fields("combustivel").Value.ToString()
                        txt_km.Text = rs.Fields("km").Value.ToString()
                        txt_venda.Text = rs.Fields("venda").Value.ToString()

                        ' Carrega a cor salva
                        If Not IsDBNull(rs.Fields("cor").Value) Then
                            cor_selecionada_hex = rs.Fields("cor").Value.ToString()
                            pnl_amostra_cor.BackColor = ColorTranslator.FromHtml(cor_selecionada_hex)
                        End If

                        ' Carrega a foto com segurança
                        diretorio = rs.Fields("foto").Value.ToString()
                        If System.IO.File.Exists(diretorio) Then
                            img_foto.Load(diretorio)
                        Else
                            img_foto.Image = Nothing ' Limpa se a foto não for encontrada
                        End If
                    End If
                ElseIf .CurrentRow.Cells(10).Selected = True Then

                    Dim aux_placa As String = .CurrentRow.Cells(1).Value.ToString()

                    ' Ajusta a mensagem perguntando sobre a placa
                    Dim resp As MsgBoxResult = MsgBox("Deseja excluir o veículo placa: " & aux_placa & "?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")

                    If resp = MsgBoxResult.Yes Then
                        sql = $"delete from tb_veiculos where placa='{aux_placa}'"
                        rs = db.Execute(sql)

                        Carregar_dados()
                        Limpar_cadastro()
                    End If
                Else
                    Exit Sub
                End If
            End With
        Catch ex As Exception
            MsgBox("Erro ao processar o clique!", MsgBoxStyle.Critical, "ERRO")
        End Try
    End Sub

    'código para fechar, minimizar e maximizar tela personalizada
    Private Sub btn_fechar_Click(sender As Object, e As EventArgs) Handles btn_fechar.Click
        Me.Close()
    End Sub

    Private Sub btn_minimizar_Click(sender As Object, e As EventArgs) Handles btn_minimizar.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub btn_maximizar_Click(sender As Object, e As EventArgs) Handles btn_maximizar.Click

        If Me.WindowState = FormWindowState.Normal Then
            Me.WindowState = FormWindowState.Maximized
        Else
            Me.WindowState = FormWindowState.Normal
        End If

    End Sub

    'Poder digitar apenas números
    Private Sub txt_box_ano_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_ano.KeyPress, txt_km.KeyPress, txt_venda.KeyPress
        ' Se a tecla pressionada NÃO for um número E NÃO for a tecla Backspace (apagar)
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            ' e.Handled = True cancela a tecla, impedindo que o caractere apareça no campo
            e.Handled = True
        End If
    End Sub


    ' Variável para guardar o valor HEX da cor para gravar no banco
    Dim cor_selecionada_hex As String = "#FFFFFF"

    Private Sub btn_escolher_cor_Click(sender As Object, e As EventArgs) Handles btn_escolher_cor.Click
        ' Abre a janela nativa do Windows para escolha de cores
        If ColorDialog1.ShowDialog() = DialogResult.OK Then
            ' Pinta o painel de amostra com a cor escolhida
            pnl_amostra_cor.BackColor = ColorDialog1.Color

            ' Converte a cor para o formato Hexadecimal (ex: #FF0000)
            'cor_selecionada_hex = ColorTranslator.ToHtml(ColorDialog1.Color)
            Dim c As Color = ColorDialog1.Color
            cor_selecionada_hex = $"#{c.R:X2}{c.G:X2}{c.B:X2}"
        End If
    End Sub

    Private Sub btn_cancelar_Click(sender As Object, e As EventArgs) Handles btn_cancelar.Click
        btn_cancelamento()
    End Sub

    Private Sub btn_carregar_foto_Click(sender As Object, e As EventArgs) Handles btn_carregar_foto.Click
        ' Configura o filtro para exibir apenas arquivos de imagem na janela de escolha
        ofd_foto.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp"
        ofd_foto.Title = "Selecione a foto do veículo"

        ' Abre a janela para selecionar a imagem
        If ofd_foto.ShowDialog() = DialogResult.OK Then
            Try
                'Garante que a pasta 'fotos' exista dentro da pasta bin\Debug do seu projeto
                Dim pastaFotos As String = System.IO.Path.Combine(Application.StartupPath, "fotos")
                If Not System.IO.Directory.Exists(pastaFotos) Then
                    System.IO.Directory.CreateDirectory(pastaFotos)
                End If

                ' Pega apenas o nome e extensão da foto escolhida (ex: "hb20.jpg")
                Dim nomeArquivo As String = System.IO.Path.GetFileName(ofd_foto.FileName)
                Dim caminhoDestino As String = System.IO.Path.Combine(pastaFotos, nomeArquivo)

                ' Copia a imagem para a pasta bin\Debug\fotos se ela veio de outro lugar (ex: Downloads)
                If ofd_foto.FileName <> caminhoDestino Then
                    System.IO.File.Copy(ofd_foto.FileName, caminhoDestino, True)
                End If

                ' 4. Carrega e exibe a imagem no PictureBox
                img_foto.Load(caminhoDestino)

                ' 5. Salva o caminho relativo ("fotos\nome.jpg") na variável que o SQL vai gravar no banco
                diretorio = "fotos\" & nomeArquivo

            Catch ex As Exception
                MessageBox.Show("Erro ao carregar a imagem: " & ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
End Class
